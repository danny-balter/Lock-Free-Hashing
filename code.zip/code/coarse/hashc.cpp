#include <stdlib.h>
#include <thread>
#include <mutex>
#include "../cycle_timer.h"


const int NUM_OPS = 600000;
const int TABLE_SIZE = 300;
const int NUM_THREADS = 24;
const int RAND_NUM = 10000000;

std::mutex mtx;

struct node {
  int key;
  node* next;
};

//going to maintain the invarient that each ll is sorted
struct ll {
  node* head;
};

typedef ll* ht;

class HashTable {
  private:
    ht hashTable;
  
  public:
    HashTable() {
      hashTable = new ll [TABLE_SIZE];
      for(int i = 0; i < TABLE_SIZE; i++) {
        hashTable[i].head = NULL;
      }
    }
    ~HashTable() {
      for(int i = 0; i < TABLE_SIZE; i++) {
        ll bucket = hashTable[i];
        node* curr = bucket.head;
        while(curr != NULL) {
          node* temp = curr;
          curr = curr->next;
          free(temp);
        }
      }
      free(hashTable);
    }

    int Hash(int key) {
      return key % TABLE_SIZE;
    }

    void Insert(int key) {
      mtx.lock();
      int hash_val = Hash(key);
      node* N = new node();
      N->key = key;
      N->next = NULL;
      //list is empty
      if(hashTable[hash_val].head == NULL) {
        hashTable[hash_val].head = N;
      }
      else if(hashTable[hash_val].head->key > key) {
        node* temp = hashTable[hash_val].head;
        hashTable[hash_val].head = N;
        N->next = temp;
      }
      //list is not empty
      else {
        node* curr = hashTable[hash_val].head;
        while(curr->next != NULL && curr->next->key < key)
        {
          if(curr->key == key) {
            mtx.unlock();
            return;
          }
          curr = curr->next;
        }
        //insert at end of list
        if(curr->key == key) {
          mtx.unlock();
          return;
        }
        if(curr->next == NULL) {
          curr->next = N;
        }
        //insert in middle of list, maintaining sorted
        else {
          node* temp = curr->next;
          curr->next = N;
          N->next = temp;
        }
      }
      mtx.unlock();
    }

    // assumes we will never remove something that doesn't exist
    void Remove(int key) {
      mtx.lock();
      int hash_val = Hash(key);
      ll bucket = hashTable[hash_val];
      node* curr = bucket.head;
      node* prev = NULL;

      while(curr != NULL && curr->key <= key) {
        if(curr->key == key) {
          // delete at beginning of list
          if(prev == NULL) {
            hashTable[hash_val].head = curr->next;
          }
          // delete anywhere but the beginning
          else {
            prev->next = curr->next;
          }
          free(curr);
        }
        prev = curr;
        curr = curr->next;
      }
      mtx.unlock();
      return;
    }

    bool Search(int key) {
      mtx.lock();
      bool found = 0;
      int hash_val = Hash(key);
      ll bucket = hashTable[hash_val];
      node* curr = bucket.head;

      while(curr != NULL && curr->key <= key) {
        if(curr->key == key) {
          found = 1;
          break;
        }
        curr = curr->next;
      }
      mtx.unlock();
      return found;
    }

    void Print_Table() {
      for(int i = 0; i < TABLE_SIZE; i++) {
        node* curr = hashTable[i].head;
        while(curr != NULL) {
          printf("%d -> ", curr->key);
          curr = curr->next;
        }
        printf("||");
        printf("\n");
      }
      printf("\n");
    }
};

HashTable hashTable;
int* tests = new int [NUM_OPS];
int mult = NUM_OPS/NUM_THREADS;

void* foo(void* ptr) {
  int id = *(int*)ptr;
  delete (int*)ptr;
  for(int i = id * mult; i < (id+1)*mult; i++) {
    hashTable.Insert(tests[i]);
  }

/*
  for(int i = id * mult; i < (id+1)*mult; i++) {
    hashTable.Search(tests[i]);
  }

  for(int i = id * mult; i < (id+1)*mult; i++) {
    hashTable.Remove(tests[i]);
  }

  */

  return NULL;
}   

int main() {
  for(int i = 0; i < NUM_OPS; i++) {
    int random = rand() % RAND_NUM;
    tests[i] = random;
  }
      double start = CycleTimer::currentSeconds();
      pthread_t threads[NUM_THREADS];
      for(int i = 0; i < NUM_THREADS; i++) {
        pthread_create(&threads[i], NULL, &foo, new int(i));
      }   
  
      for(int i = 0; i < NUM_THREADS; i++) {
        pthread_join(threads[i], NULL);
      }   
      double end = CycleTimer::currentSeconds();
      double time = end - start;
      printf("Average Runtime for %d threads : %f \n" , NUM_THREADS, time);
  return 0;
}
