#include <stdlib.h>
#include <thread>
#include <mutex>
#include "../cycle_timer.h"

const int TABLE_SIZE = 100;
const int NUM_THREADS = 24;

std::mutex* bucket_mtx;

struct node {
  int key;
  int value;
  node* next;
  std::mutex mtx;
};

//going to maintain the invarient that each ll is sorted
struct ll {
  node* head;
  int size;
};

typedef ll* ht;

class WriterLock {
  private:
    std::mutex* m_;
  
  public:
    WriterLock(std::mutex* m) {
      m_ = m;
      m_->lock();
    }
    ~WriterLock() {
      m_->unlock();
    }
};

class WriterLock2 {
  private:
    std::mutex* m1_{nullptr};
    std::mutex* m2_{nullptr};

  public:
    // m is already locked
    WriterLock2(std::mutex* m) {
      m2_ = m;
    }
    void AddMutex(std::mutex* m) {
      if (m1_ != nullptr) m1_->unlock();
      m1_ = m2_;
      m2_ = m;
      m2_->lock();
    }
    ~WriterLock2() {
      if (m1_ != nullptr) m1_->unlock();
      m2_->unlock();
    }
};


class HashTable {
  private:
    ht hashTable;
  
  public:
    HashTable() {
      bucket_mtx = new std::mutex [TABLE_SIZE];
      hashTable = new ll [TABLE_SIZE];
      for(int i = 0; i < TABLE_SIZE; i++) {
        hashTable[i].head = NULL;
        hashTable[i].size = 0;
      }
    }
    ~HashTable() {
      for(int i = 0; i < TABLE_SIZE; i++) {
        ll bucket = hashTable[i];
        node* curr = bucket.head;
        while(curr != NULL) {
          node* temp = curr;
          curr = curr->next;
          free(temp);
        }
      }
      free(hashTable);
      free(bucket_mtx);
    }

    int Hash(int key) {
      return key % TABLE_SIZE;
    }

    void Insert(int key, int value) {
      int hash_val = Hash(key);
      //node* N = (node *) malloc (sizeof(node));
      node* N = new node;
      N->key = key;
      N->value = value;
      N->next = NULL;
      {
        WriterLock w(&bucket_mtx[hash_val]);
        //if bucket is empty
        if(hashTable[hash_val].head == NULL) {
          hashTable[hash_val].head = N;
          bucket_mtx[hash_val].unlock();
          return;
        }
        hashTable[hash_val].head->mtx.lock();
        if(hashTable[hash_val].head->key > key)
        {
          node* temp = hashTable[hash_val].head;
          hashTable[hash_val].head = N;
          N->next = temp;
          temp->mtx.unlock();
          return;
        }
      }
      //if bucket is not empty
      node* curr = hashTable[hash_val].head;
      node* prev = NULL;
      
      WriterLock2 m(&curr->mtx);

      while(curr->key < key && curr->next != NULL) {
        prev = curr;
        m.AddMutex(&curr->next->mtx);
        curr = curr->next;
      }
      //in case someone else inserted while we were looking for location
      if(curr->key == key) {
        free(N);
        return;
      }
      //insert in middle of list, and we found the spot
      if(curr->key > key) {
        prev->next = N;
        N->next = curr;
        return;
      }
      //insert at end of a list
      else {
        curr->next = N;
        return;
      }
    } 

    // assumes we will never remove something that doesn't exist
    void Remove(int key) {
      int hash_val = Hash(key);
      ll bucket = hashTable[hash_val];
      node* curr = bucket.head;
      node* prev = NULL;

      while(curr != NULL && curr->key <= key) {
        if(curr->key == key) {
          // delete at beginning of list
          if(prev == NULL) {
            hashTable[hash_val].head = curr->next;
          }
          // delete anywhere but the beginning
          else {
            prev->next = curr->next;
          }
          free(curr);
          hashTable[hash_val].size--;
        }
        prev = curr;
        curr = curr->next;
      }
    }

    bool Search(int key) {
      bool found = 0;
      int hash_val = Hash(key);
      bucket_mtx[hash_val].lock();
      if(hashTable[hash_val].head == NULL)
        return found;
      else {
        hashTable[hash_val].head->mtx.lock();
        node* curr = hashTable[hash_val].head;
        while(curr != NULL && curr->key <= key) {
          if(curr->key == key) {
            found = 1;
            break;
          }
          curr->next->mtx.lock();
          curr->mtx.unlock();
          curr = curr->next;
        }
        curr->mtx.unlock();
        return found;
      }
    }

    void Table_Sizes() {
      for(int i = 0; i < TABLE_SIZE; i++) {
        printf("Size at index %d is: %d \n", i, hashTable[i].size);
      }
      printf("\n");
    }

    void Print_Table() {
      for(int i = 0; i < TABLE_SIZE; i++) {
        node* curr = hashTable[i].head;
        while(curr != NULL) {
          printf("%d -> ", curr->key);
          curr = curr->next;
        }
        printf("||");
        printf("\n");
      }
      printf("\n");
    }

};

HashTable hashTable;

void* foo(void* ptr) {
  int id = *(int*)ptr;
  delete (int*)ptr;
  for(int i = id*10000; i < (id+1)*10000; i++) {
    //if(!hashTable.Search(i)) 
      hashTable.Insert(i,0);
  }

  /*
  for(int i = id*100000; i < (id+1)*100000; i++) {
    if(hashTable.Search(i)) 
      hashTable.Remove(i);
  }
  */

  return NULL;
}   


int main() {

  double start = CycleTimer::currentSeconds();
  pthread_t threads[NUM_THREADS];
  for(int i = 0; i < NUM_THREADS; i++) {
    pthread_create(&threads[i], NULL, &foo, new int(i));
  }
  
  for(int i = 0; i < NUM_THREADS; i++) {
    pthread_join(threads[i], NULL);
  }
  double end = CycleTimer::currentSeconds();
  double time = end - start;
  printf("Total Runtime: %f \n" , time);


  /*
  printf("%d \n", hashTable.Search(1));

  for(int i = 0; i<10; i++) {
    hashTable.Remove(i);
  }

  hashTable.Print_Table();
 
  printf("%d \n", hashTable.Search(1));

  */

  return 0;

}
