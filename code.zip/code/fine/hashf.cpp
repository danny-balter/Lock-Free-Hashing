#include <stdlib.h>
#include <thread>
#include <mutex>
#include "../cycle_timer.h"

const int NUM_OPS = 600;
const int TABLE_SIZE = 6;
const int RAND_NUM = 10000000;
const int NUM_THREADS = 24;

std::mutex* bucket_mtx;

struct node {
  int key;
  node* next;
  std::mutex mtx;
};

//going to maintain the invarient that each ll is sorted
struct ll {
  node* head;
};

typedef ll* ht;

class WriterLock {
  private:
    std::mutex* m_;
  
  public:
    WriterLock(std::mutex* m) {
      m_ = m;
      m_->lock();
    }
    ~WriterLock() {
      m_->unlock();
    }
};

class WriterLock2 {
  private:
    std::mutex* m1_{nullptr};
    std::mutex* m2_{nullptr};

  public:
    // m is already locked
    WriterLock2(std::mutex* m) {
      m2_ = m;
    }
    void AddMutex(std::mutex* m) {
      if (m1_ != nullptr) m1_->unlock();
      m1_ = m2_;
      m2_ = m;
      m2_->lock();
    }
    ~WriterLock2() {
      if (m1_ != nullptr) m1_->unlock();
      m2_->unlock();
    }
};


class HashTable {
  private:
    ht hashTable;
  
  public:
    HashTable() {
      bucket_mtx = new std::mutex [TABLE_SIZE];
      hashTable = new ll [TABLE_SIZE];
      for(int i = 0; i < TABLE_SIZE; i++) {
        hashTable[i].head = NULL;
      }
    }
    ~HashTable() {
      for(int i = 0; i < TABLE_SIZE; i++) {
        ll bucket = hashTable[i];
        node* curr = bucket.head;
        while(curr != NULL) {
          node* temp = curr;
          curr = curr->next;
          free(temp);
        }
      }
      free(hashTable);
      free(bucket_mtx);
    }

    int Hash(long long int key) {
      return key % TABLE_SIZE;
    }

    void Insert(long long int key) {
      int hash_val = Hash(key);
      node* N = new node;
      //(node *) malloc (sizeof(node));
      N->key = key;
      N->next = NULL;
      {
        //WriterLock w(&bucket_mtx[hash_val]);
         bucket_mtx[hash_val].lock();
        //if bucket is empty
        if(hashTable[hash_val].head == NULL) {
          hashTable[hash_val].head = N;
          bucket_mtx[hash_val].unlock();
          return;
        }
        hashTable[hash_val].head->mtx.lock();
        if(hashTable[hash_val].head->key > key)
        {
          node* temp = hashTable[hash_val].head;
          hashTable[hash_val].head = N;
          N->next = temp;
          temp->mtx.unlock();
          bucket_mtx[hash_val].unlock();
          return;
        }
      }
       bucket_mtx[hash_val].unlock();
      //if bucket is not empty
      node* curr = hashTable[hash_val].head;
      node* prev = NULL;
      
      //WriterLock2 m(&curr->mtx);

      while(curr->key < key && curr->next != NULL) {
        
        if(prev != NULL) {
          prev->mtx.unlock();
        }
        
        prev = curr;
        //m.AddMutex(&curr->next->mtx);
        curr->next->mtx.lock();
        curr = curr->next;
      }
      //in case someone else inserted while we were looking for location
      if(curr->key == key) {
        
        if(prev != NULL)
          prev->mtx.unlock();
        curr->mtx.unlock();
        
        free(N);
        return;
      }
      //insert in middle of list, and we found the spot
      if(curr->key > key) {
        prev->next = N;
        N->next = curr;
        
        if(prev != NULL)
          prev->mtx.unlock();
        curr->mtx.unlock();
        
        return;
      }
      //insert at end of a list
      else {
        
        if(prev != NULL)
          prev->mtx.unlock();
        
        curr->next = N;
        curr->mtx.unlock();
        return;
      }
    } 

    // assumes we will never remove something that doesn't exist
    void Remove(long long int key) {
      int hash_val = Hash(key);
      bucket_mtx[hash_val].lock();
      if(hashTable[hash_val].head == NULL) {
        bucket_mtx[hash_val].unlock();
        return;
      }
      hashTable[hash_val].head->mtx.lock();
      node* curr = hashTable[hash_val].head;
      node* prev = NULL;
      node* next = NULL;
      if(curr->next != NULL) {
        curr->next->mtx.lock();
        next = curr->next;
      }
      if(curr->key == key) {
        hashTable[hash_val].head = next;
        bucket_mtx[hash_val].unlock();
        curr->mtx.unlock();
        if(next != NULL)
          next->mtx.unlock();
        return;
      }
      bucket_mtx[hash_val].unlock();
      while(curr != NULL) {
        //found
        if(curr->key == key) {
          prev->next = next;
        }
        //not there
        if(curr->key > key) {
          curr->mtx.unlock();
          if(prev != NULL) {
            prev->mtx.unlock();
          }
          if(next != NULL) {
            next->mtx.unlock();
          }
          return;
        }
        //iterate
        else {
          prev->mtx.unlock();
          prev = curr;
          curr = next;
          if(curr->next != NULL) {
            curr->next->mtx.lock();
            next = curr->next;
          }
        }
      }
      if(prev != NULL) {
        prev->mtx.unlock();
      }
      if(next != NULL) {
        next->mtx.unlock();
      }
      curr->mtx.unlock();
      return;
    }

    bool Search(long long int key) {
      bool found = 0;
      int hash_val = Hash(key);
      bucket_mtx[hash_val].lock();
      if(hashTable[hash_val].head == NULL) {
        bucket_mtx[hash_val].unlock();
        return found;
      }
      else {
        hashTable[hash_val].head->mtx.lock();
        node* prev = NULL;
        node* curr = hashTable[hash_val].head;
        bucket_mtx[hash_val].unlock();
        while(curr->next != NULL && curr->key < key) {
          if(prev != NULL) {
            prev->mtx.unlock();
          }
          prev = curr;
          curr->next->mtx.lock();
          curr = curr->next;
        }
        //found
        if(curr->key == key) {
          if(prev != NULL) prev->mtx.unlock();
          curr->mtx.unlock();
          found = 1;
          return found;
        }
        //nope
        else {
          if(prev != NULL) prev->mtx.unlock();
          curr->mtx.unlock();
          return found;
        }
      }
    }

    void Print_Table() {
      for(int i = 0; i < TABLE_SIZE; i++) {
        node* curr = hashTable[i].head;
        while(curr != NULL) {
          printf("%d -> ", curr->key);
          curr = curr->next;
        }
        printf("||");
        printf("\n");
      }
      printf("\n");
    }

};

HashTable hashTable;
int* tests = new int [NUM_OPS];
int mult = NUM_OPS/NUM_THREADS;

void* foo(void* ptr) {
  int id = *(int*)ptr;
  delete (int*)ptr;

  for(int i = id * mult; i < (id+1)*mult; i++) {
    hashTable.Insert(tests[i]);
  }

  return NULL;
}   

int main() {
  for(int i = 0; i < NUM_OPS; i++) {
    int random = rand() % RAND_NUM;
    tests[i] = random;
  }
  

      double start = CycleTimer::currentSeconds();
      pthread_t threads[NUM_THREADS];
      for(int i = 0; i < NUM_THREADS; i++) {
        pthread_create(&threads[i], NULL, &foo, new int(i));
      }   
  
      for(int i = 0; i < NUM_THREADS; i++) {
        pthread_join(threads[i], NULL);
      }   
      double end = CycleTimer::currentSeconds();
      double time = end - start;
    printf("Runtime for %d threads : %f \n" , NUM_THREADS, 2*time);
  
  return 0;
}

