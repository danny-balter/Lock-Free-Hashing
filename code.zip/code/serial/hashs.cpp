#include <stdlib.h>
#include <thread>
#include <mutex>
#include "../cycle_timer.h"


const int NUM_OPS = 2400000;
const int TABLE_SIZE = 10000000;
const int RAND_NUM = TABLE_SIZE;


struct node {
  int key;
  node* next;
};

//going to maintain the invarient that each ll is sorted
struct ll {
  node* head;
};

typedef ll* ht;

class HashTable {
  private:
    ht hashTable;
  
  public:
    HashTable() {
      hashTable = new ll [TABLE_SIZE];
      for(int i = 0; i < TABLE_SIZE; i++) {
        hashTable[i].head = NULL;
      }
    }
    ~HashTable() {
      for(int i = 0; i < TABLE_SIZE; i++) {
        ll bucket = hashTable[i];
        node* curr = bucket.head;
        while(curr != NULL) {
          node* temp = curr;
          curr = curr->next;
          free(temp);
        }
      }
      free(hashTable);
    }

    int Hash(int key) {
      return key % TABLE_SIZE;
    }

    void Insert(int key) {
      int hash_val = Hash(key);
      node* N = new node();
      N->key = key;
      N->next = NULL;
      //list is empty
      if(hashTable[hash_val].head == NULL) {
        hashTable[hash_val].head = N;
      }
      else if(hashTable[hash_val].head->key > key) {
        node* temp = hashTable[hash_val].head;
        hashTable[hash_val].head = N;
        N->next = temp;
      }
      //list is not empty
      else {
        node* curr = hashTable[hash_val].head;
        while(curr->next != NULL && curr->next->key < key)
        {
          if(curr->key == key) {
            return;
          }
          curr = curr->next;
        }
        //insert at end of list
        if(curr->key == key) {
          return;
        }
        if(curr->next == NULL) {
          curr->next = N;
        }
        //insert in middle of list, maintaining sorted
        else {
          node* temp = curr->next;
          curr->next = N;
          N->next = temp;
        }
      }
    }

    // assumes we will never remove something that doesn't exist
    void Remove(int key) {
      int hash_val = Hash(key);
      ll bucket = hashTable[hash_val];
      node* curr = bucket.head;
      node* prev = NULL;

      while(curr != NULL && curr->key <= key) {
        if(curr->key == key) {
          // delete at beginning of list
          if(prev == NULL) {
            hashTable[hash_val].head = curr->next;
          }
          // delete anywhere but the beginning
          else {
            prev->next = curr->next;
          }
          free(curr);
        }
        prev = curr;
        curr = curr->next;
      }
      return;
    }

    bool Search(int key) {
      bool found = 0;
      int hash_val = Hash(key);
      ll bucket = hashTable[hash_val];
      node* curr = bucket.head;

      while(curr != NULL && curr->key <= key) {
        if(curr->key == key) {
          found = 1;
          break;
        }
        curr = curr->next;
      }
      return found;
    }

    void Print_Table() {
      for(int i = 0; i < TABLE_SIZE; i++) {
        node* curr = hashTable[i].head;
        while(curr != NULL) {
          printf("%d -> ", curr->key);
          curr = curr->next;
        }
        printf("||");
        printf("\n");
      }
      printf("\n");
    }
};

HashTable hashTable;

void foo() {

  for(int i = 0; i < NUM_OPS; i++) {
    int random = rand() % RAND_NUM;
    hashTable.Insert(random);
  }

  for(int i = 0; i < NUM_OPS; i++) {
    int random = rand() % RAND_NUM;
    hashTable.Search(random);
  }

  for(int i = 0; i < NUM_OPS; i++) {
    int random = rand() % RAND_NUM;
    hashTable.Remove(random);
  }
 
  return;
}   

int main() {


  double start = CycleTimer::currentSeconds();
  foo();

  double end = CycleTimer::currentSeconds();
  double time = end - start;
  printf("Total Runtime: %f \n" , time);  

  return 0;

}
