#include <stdlib.h>
#include <thread>
#include <mutex>
#include <atomic>
#include <memory>

#include "../cycle_timer.h"

const int NUM_OPS = 600000;
const int TABLE_SIZE = 6000;
const int RAND_NUM = 10000000;
const int NUM_THREADS = 24;


struct node {
  node(int key):key(key){}
  node() {}
  int key;
  node* left;
  node* right;
  bool marked;
};

class BoolMarked {
  public:
    BoolMarked(bool* b):b(b) {
      while(!__sync_bool_compare_and_swap(b,false,true));
    }
    ~BoolMarked() {
      *b = false;
    }
  private:
    bool* b;
};

class MarkedNode {

  public: 
    bool AcquireLock(node** nd) {
      //printf("attempting to acquire lock on node: %d \n",(*nd)->key);
      //this is wasteful, if it works we can make it more efficient
      node* curr = *nd;
      if(curr == NULL) return false;
      *temp = *curr;
      bool is_marked = temp->marked;
      temp->marked = true;
      while(is_marked || !__sync_bool_compare_and_swap(
                nd,curr,temp.get())) {   
        curr = *nd;
        *temp = *curr;
        is_marked = temp->marked;
        temp->marked = true;
      }
      Acquire(temp.release());
      temp.reset(curr);
      //printf("acquired lock on node: %d \n",marked->key);
      return true;
    }
    node* Transfer() {
      node* temp = marked;
      marked = NULL;
      return temp;
    }
    void Acquire(node* nd) {
      if(marked != NULL) {
        //printf("unmarking node: %d \n",marked->key);
        marked->marked = false;
      }
      marked = nd;
    }
    MarkedNode():temp(new node()) {}
    ~MarkedNode() {
      Acquire(NULL);
    }

  private: 
    std::unique_ptr<node> temp;
    node* marked = NULL;
};

//going to maintain the invarient that each ll is sorted
struct ll {
  node* head;
  bool bmarked;
};

typedef ll* ht;

class HashTable {
  private:
    ht hashTable;
  
  public:
    HashTable() {
      hashTable = new ll [TABLE_SIZE];
      for(int i = 0; i < TABLE_SIZE; i++) {
        hashTable[i].head = NULL;
        hashTable[i].bmarked = false;
      }
    }
    void destroy (node* h) {
      if(h == NULL) return ;
      destroy(h->left);
      destroy(h->right);
      free(h);
      return;
    }
    ~HashTable() {
      for(int i = 0; i < TABLE_SIZE; i++) {
        destroy(hashTable[i].head);   
      }
      free(hashTable);
    }

    int Hash(long long int key) {
      return (key * 9379261) % TABLE_SIZE;
    }
/*
    void Table_Sizes() {
      for(int i = 0; i < TABLE_SIZE; i++) {
        printf("Size at index %d is: %d \n", i, hashTable[i].size);
      }   
      printf("\n");
    } 

*/

    void Insert(long long int key) {
      int hash_val = Hash(key);
      MarkedNode mn1;
      MarkedNode mn2;
      node** curr;
      //printf("inserting key: %d to bucket: %d \n", key,hash_val);
      //printf("inserted : %d \n", inserted.load());
      std::unique_ptr<node> N(new node(key));
      N->left = NULL;
      N->right = NULL;
      N->marked = false;
      
      {
        BoolMarked b(&hashTable[hash_val].bmarked);
        while(true)
        {
          if(__sync_bool_compare_and_swap(&hashTable[hash_val].head,
            NULL,N.get())) {
            N.release();
            return;
          }
        
          if(mn1.AcquireLock(&hashTable[hash_val].head))
            break;
        }
      

        curr = &hashTable[hash_val].head;
      }
      
      while(true) {
        if(*curr == NULL) {
          *curr = N.release();
          return ;
        }
        else if(key == (*curr)->key) return;
        else {
          if(key < (*curr)->key) {
            curr = &((*curr)->left);
          }
          else {
            curr = &((*curr)->right);
          }
          if(*curr != NULL) {
            mn2.AcquireLock(curr);
            mn1.Acquire(mn2.Transfer());
          }
        }
      }
    }

    //want to remove at curr, prev is previous node to curr
    void Remove_Help(node** curr, node** prev, int key) {
      MarkedNode mn1;
      MarkedNode mn2;
      MarkedNode mnt;
      int hash_val = Hash(key);
      if((*curr)->left == NULL && (*curr)->right == NULL) {
        node* del = *curr;
        if(prev != NULL && *prev != NULL) {
          if(key < (*prev)->key) {
            (*prev)->left = NULL;
          }
          else {
            (*prev)->right = NULL;
          }
          delete del;
        }
        else {
          *curr = NULL;
          delete del;
        }
        return;
      }
      //left child of remove node
      else if((*curr)->left != NULL && (*curr)->right == NULL) {
        node* temp = (*curr)->left;
        free(*curr); 
        if(prev != NULL && *prev != NULL) {
          if(key < (*prev)->key) {
            (*prev)->left = temp;
          }   
          else {
            (*prev)->right = temp;
          }   
        }   
        else {
          *curr = temp;
        }   
        return;
      }
      //right child of remove node
      else if((*curr)->left == NULL && (*curr)->right != NULL) {
        node* temp = (*curr)->right;
        free(*curr);
        if(prev != NULL && *prev != NULL) {
          if(key < (*prev)->key) {
            (*prev)->left = temp;
          }  
          else {
            (*prev)->right = temp;
          }
        }
        else {
          *curr = temp;
        }
        return;
      }
      //both
      else {
        mn1.AcquireLock(&((*curr)->right));
        node** itc = &((*curr)->right);
        node** itp = NULL;
        //walk as far down the left as possible
        while((*itc)->left != NULL) {
          itp = itc;
          mnt.AcquireLock(&(*itc)->left);
          mn2.Acquire(mn1.Transfer());
          mn1.Acquire(mnt.Transfer());
          itc = &((*itc)->left);
        }
        node* cpy = *itc;
        (*curr)->key = (*itc)->key;
        //if there is no right child
        if((*itc)->right == NULL) {
          if(itp != NULL && *itp != NULL) {
            (*itp)->left = NULL;
          }
          else {
            (*curr)->right = NULL;
          }
        }
        //there is a right child
        else {
          MarkedNode c;
          c.AcquireLock(&((*itc)->right));
          node* temp = (*itc)->right;
          if(itp != NULL && *itp != NULL) {
            (*itp)->left = temp;
          }
          else {
            (*curr)->right = temp;
          }
        }
        free(cpy);
        return;
      }
    }

    void Remove(long long int key) {
      int hash_val = Hash(key);
      MarkedNode mnc;
      MarkedNode mnp;
      MarkedNode mnt;
      
      {
        BoolMarked b(&hashTable[hash_val].bmarked);
        //grabbing head lock
        while(true) {
          if(hashTable[hash_val].head == NULL) {
            return;
          }
          if(mnc.AcquireLock(&hashTable[hash_val].head)) break;
        }
        if(hashTable[hash_val].head == NULL) return;
        if(hashTable[hash_val].head->key == key) {
          Remove_Help(&hashTable[hash_val].head,NULL,key);
          return;
        }
        else if(key < hashTable[hash_val].head->key) {
          if(hashTable[hash_val].head->left == NULL) return;
          else {
            Remove_Help(&(hashTable[hash_val].head->left),
                        &hashTable[hash_val].head,key);
            return;
          }
        }
        else {
          if(hashTable[hash_val].head->right == NULL) return;
          else {
            Remove_Help(&(hashTable[hash_val].head->right),
                        &hashTable[hash_val].head,key);
            return;
          }
        }
      
      }

      node** curr = &hashTable[hash_val].head;
      node** prev = NULL;
      //searching for the node to delete
      while(true) {
        if(*curr == NULL) return;
        //found it
        if(key == (*curr)->key) {
          //we found the node to remove, now we have to find the node to swap
          //keys with and then place that node's child if they exist.
          //0 children of removed node
          Remove_Help(curr,prev,key);
          return;
          
        }
        else if(key < (*curr)->key) {
          if((*curr)->left != NULL) {
            prev = curr;
            mnt.AcquireLock(&((*curr)->left));
            mnp.Acquire(mnc.Transfer());
            mnc.Acquire(mnt.Transfer());
            curr = &((*curr)->left);
          }
          else {
            return;
          }
        }
        //key > curr->key
        else {
          if((*curr)->right != NULL) {
            prev = curr;
            mnt.AcquireLock(&((*curr)->right));
            mnp.Acquire(mnc.Transfer());
            mnc.Acquire(mnt.Transfer());
            curr = &((*curr)->right);
          }
          else {
            return;
          }
        }
      } 
    }


    bool Search(long long int key) {
      int hash_val = Hash(key);
      MarkedNode mn1;
      MarkedNode mn2;

      {
        BoolMarked b(&hashTable[hash_val].bmarked);

        while(true) {
          if(hashTable[hash_val].head == NULL) 
          {
            return false;
          }
          if(mn1.AcquireLock(&hashTable[hash_val].head)) break;
        }

      }

      node* curr = hashTable[hash_val].head;
      while(true) {
        if(curr == NULL) { //printf("Not Found \n");  
        return false;}
        if(curr->key == key) { //printf("Found \n"); 
        return true; }
        else if(key < curr->key) {
          if(curr->left != NULL) {
            mn2.AcquireLock(&curr->left);
            curr = curr->left;
            mn1.Acquire(mn2.Transfer());
          }
          else { return false; }
        }
        else {
          if(curr->right != NULL) {
            mn2.AcquireLock(&curr->right);
            curr = curr->right;
            mn1.Acquire(mn2.Transfer());
          }
          else { return false; }
        }
        //we moved another level without finding it and need to take locks
      }
    }

    void Print_Tree(node* h) {
      if(h == NULL) return;
      Print_Tree(h->left);
      printf("%d -> ",h->key);
      Print_Tree(h->right);
    }

    void Print_Table() {
      for(int i = 0; i < TABLE_SIZE; i++) {
        node* curr = hashTable[i].head;
        Print_Tree(curr);
        printf(" || ");
        printf("\n");
      }
    }

};

HashTable hashTable;
int* tests = new int [NUM_OPS];
int mult = NUM_OPS/NUM_THREADS;

void* foo(void* ptr) {
  int id = *(int*)ptr;
  delete (int*)ptr;

  for(int i = id * mult; i < (id+1)*mult; i++) {
    hashTable.Insert(tests[i]);
  }
  
  return NULL;
}

int main() {
  for(int i = 0; i < NUM_OPS; i++) {
    int random = rand() % RAND_NUM;
    tests[i] = random;
  }

      double start = CycleTimer::currentSeconds();
      pthread_t threads[NUM_THREADS];
      for(int i = 0; i < NUM_THREADS; i++) {
        pthread_create(&threads[i], NULL, &foo, new int(i));
      }   

      for(int i = 0; i < NUM_THREADS; i++) {
        pthread_join(threads[i], NULL);
      }   
      double end = CycleTimer::currentSeconds();
      double time = end - start;
    printf("Runtime for %d threads : %f \n" , NUM_THREADS, time);
//    hashTable.Print_Table();
  return 0;
}
