#include <stdlib.h>
#include <thread>
#include <mutex>
#include <atomic>
#include <memory>

#include "../cycle_timer.h"

const int NUM_OPS = 6000000;
const int TABLE_SIZE = 30000000;
const int RAND_NUM = 10000000;
const int NUM_THREADS = 24;


struct node {
  node(int key):key(key) {}
  node() {}
  int key;
  node* next;
  bool marked;
};

class BoolMarked {
  public:
    BoolMarked(bool *b):b(b) {
      while(!__sync_bool_compare_and_swap(b,false,true));
    }
    ~BoolMarked() {
      *b = false;
    }
  private:
    bool* b;
};

class MarkedNode {

  public: 
    bool AcquireMark(node** nd) {
      node* curr = *nd;
      if(curr == NULL) return false;
      *temp = *curr;
      bool is_marked = temp->marked;
      temp->marked = true;
      while(is_marked || 
        !__sync_bool_compare_and_swap(
        nd,curr,temp.get())) {   
        curr = *nd;
        *temp = *curr;
        is_marked = temp->marked;
        temp->marked = true;
      }
      Acquire(temp.release());
      temp.reset(curr);
      return true;
    }
    node* Transfer() {
      node* temp = marked;
      marked = NULL;
      return temp;
    }
    void Acquire(node* nd) {
      if(marked != NULL) {
        marked->marked = false;
      }
      marked = nd;
    }
    MarkedNode():temp(new node()) {}
    ~MarkedNode() {
      Acquire(NULL);
    }

  private: 
    std::unique_ptr<node> temp;
    node* marked = NULL;
};

//going to maintain the invarient that each ll is sorted
struct ll {
  node* head;
  bool bmarked;
};

typedef ll* ht;

class HashTable {
  private:
    ht hashTable;
  
  public:
    HashTable() {
      hashTable = new ll [TABLE_SIZE];
      for(int i = 0; i < TABLE_SIZE; i++) {
        hashTable[i].head = NULL;
        hashTable[i].bmarked = false;
      }
    }
    ~HashTable() {
      for(int i = 0; i < TABLE_SIZE; i++) {
        node* curr = hashTable[i].head;
        while(curr != NULL) {
          node* temp = curr;
          curr = curr->next;
          free(temp);
        }
      }
      free(hashTable);
    }

    int Hash(long long int key) {
      return (key * 9379261) % TABLE_SIZE;
    }

    void Insert(long long int key) {
      int hash_val = Hash(key);
      MarkedNode mn1;
      MarkedNode mn2;
      MarkedNode mnn;
      node* curr;
      node* prev;
      std::unique_ptr<node> N(new node(key));
      N->next = NULL;
      N->marked = false;
      
      {
        BoolMarked b(&hashTable[hash_val].bmarked);
        while(true) {
          if(__sync_bool_compare_and_swap(&hashTable[hash_val].head,NULL,N.get())) {
            N.release();
            return; 
          }
          if(mn1.AcquireMark(&hashTable[hash_val].head)) break;
        }  
        
        curr = hashTable[hash_val].head;
        
        if(curr == NULL) { hashTable[hash_val].head = N.release(); return ; }
        if(curr->key == key) return;
        if(curr->key > key) {
          node* temp = hashTable[hash_val].head;
          N->next = temp;
          hashTable[hash_val].head = N.release();
          return;
        }
      }
      //not inserting at head!
      prev = curr;
      mnn.AcquireMark(&(curr->next));
      mn2.Acquire(mn1.Transfer());
      mn1.Acquire(mnn.Transfer());
      curr = curr->next;

      while(true) {
        if(curr == NULL) { 
          node* temp = N.release();
          curr = temp;
          prev->next = temp;
          return;
        }
        else if (curr->key == key) return;
        else if (curr->key > key) {
          node* temp = N.release();
          prev->next = temp;
          temp->next = curr;
          return;
        }
        else {
          prev = curr;
          mnn.AcquireMark(&(curr->next));
          mn2.Acquire(mn1.Transfer());
          mn1.Acquire(mnn.Transfer());
          curr = curr->next;

        }
      }
    }


    // assumes we will never remove something that doesn't exist
    void Remove(long long int key) {
      int hash_val = Hash(key);
      MarkedNode mnp;
      MarkedNode mnc;
      MarkedNode mnn;
      MarkedNode mnnn;
      node* curr;
      node* prev;
      {
        BoolMarked b(&hashTable[hash_val].bmarked);
        while(true) {
          if(hashTable[hash_val].head == NULL) return;

          if(mnc.AcquireMark(&hashTable[hash_val].head)) break;
        }
      
        curr = hashTable[hash_val].head;
        if(curr == NULL) return;
        mnn.AcquireMark(&(curr->next));

        if(curr->key == key) {
          hashTable[hash_val].head = curr->next;
          return;
        }
      }
      prev = NULL;
      mnp.Acquire(mnc.Transfer());
      prev = curr;
      mnc.Acquire(mnn.Transfer());
      curr = curr->next;
      if(curr != NULL) {
        mnnn.AcquireMark(&(curr->next));
        mnn.Acquire(mnnn.Transfer());
      }
      
      auto temp = curr;
      while(true) {
        printf("in while true \n");
        if(curr == NULL || curr->key > key) 
        {
          printf("hit end / didn't find \n");
          return;
        }
        if(curr->key == key) {
          printf("found and removed \n");
          prev->next = curr->next;
          free(temp);
          return;
        }
        mnp.Acquire(mnc.Transfer());
        prev = curr;
        mnc.Acquire(mnn.Transfer());
        curr = curr->next;
        if(curr != NULL)
          mnnn.AcquireMark(&(curr->next));
          mnn.Acquire(mnnn.Transfer());
      }
    }

    bool Search(long long int key) {
      int hash_val = Hash(key);
      MarkedNode mn1;
      MarkedNode mn2;
      node* curr;
      {
        BoolMarked b(&hashTable[hash_val].bmarked);
        while(true) {
          if(hashTable[hash_val].head == NULL) return false;
          if(mn1.AcquireMark(&hashTable[hash_val].head)) break;
        }
        curr = hashTable[hash_val].head;
        if(curr == NULL) return false;
        if(curr->key == key) return true;
        if(curr->key > key) return false;  
      }
      mn2.AcquireMark(&curr->next);
      curr = curr->next;
      mn1.Acquire(mn2.Transfer());

      while(true) {
        if(curr->key > key) return false;
        if(curr->key == key) return true;
        if(curr->next == NULL) return false;
        mn2.AcquireMark(&curr->next);
        curr = curr->next;
        mn1.Acquire(mn2.Transfer());
      }
      return false;
     
    }

    void Print_Table() {
      for(int i = 0; i < TABLE_SIZE; i++) {
        node* curr = hashTable[i].head;
        while(curr != NULL) {
          printf("%d -> ", curr->key);
          curr = curr->next;
        }
        printf("||");
        printf("\n");
      }
      printf("\n");
    }

};

HashTable hashTable;
int* tests = new int [NUM_OPS];
int mult = NUM_OPS/NUM_THREADS;

void* foo(void* ptr) {
  int id = *(int*)ptr;
  delete (int*)ptr;

  for(int i = id * mult; i < (id+1)*mult; i++) {
    hashTable.Insert(tests[i]);
  }

  for(int i = id * mult; i > (id+1)*mult; i++) {
    hashTable.Remove(tests[i]);
  }
  return NULL;
}

int main() {
  for(int i = 0; i < NUM_OPS; i++) {
    int random = rand() % RAND_NUM;
    tests[i] = random;
  }


      double start = CycleTimer::currentSeconds();
      pthread_t threads[NUM_THREADS];
      for(int i = 0; i < NUM_THREADS; i++) {
        pthread_create(&threads[i], NULL, &foo, new int(i));
      }

      for(int i = 0; i < NUM_THREADS; i++) {
        pthread_join(threads[i], NULL);
      }
      double end = CycleTimer::currentSeconds();
      double time = end - start;
    printf("Runtime for %d threads : %f \n" , NUM_THREADS, time);

  return 0;
}

